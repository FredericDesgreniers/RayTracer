Includes every feature mentioned in the assignment outline, including extra credit stuff. 

Renders what's in scene.txt